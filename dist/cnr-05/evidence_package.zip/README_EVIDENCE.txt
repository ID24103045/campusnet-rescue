CAMPUSNET RESCUE - EVIDENCE PACKAGE (SYNTHETIC)
Workstation: labpc01 (fictional). All data is fabricated for the CTF.
Notes from the evidence handler:
 - logs/auth.log uses the workstation local time zone: Asia/Colombo (UTC+05:30), no year shown (year is 2026).
 - browser/*/History are SQLite files; timestamps are microseconds since 1601-01-01 00:00:00 UTC.
 - fs/bodyfile.csv timestamps are UTC epoch seconds.
Question: which account was used for the suspicious portal activity, which artefact did it produce,
and when did the suspicious session begin?
Flag format: IE3132{account_artefact_YYYYMMDDTHHMMSSZ}
 - account: lowercase login name
 - artefact: lowercase file name with every '.' and '_' replaced by '-'
 - time: the moment the suspicious session was ACCEPTED, in UTC
